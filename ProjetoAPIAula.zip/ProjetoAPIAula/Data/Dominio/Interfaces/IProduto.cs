﻿using Data.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Dominio.Interfaces
{
   public  interface IProduto : IGeneric<Produto>
    {
    }
}
